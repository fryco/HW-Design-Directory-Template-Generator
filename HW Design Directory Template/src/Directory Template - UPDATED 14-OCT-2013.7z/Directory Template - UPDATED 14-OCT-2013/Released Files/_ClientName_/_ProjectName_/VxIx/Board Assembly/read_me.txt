Place following files here:

- TOP and BOTTOM Layer + TOP and BOTTOM Paste Gerber Files (for stencil)
- Pick and Place
- Bill of Materials (grouped by component type)
- Component reference BOM (each component on one line: Designator, Description, Manufacturer 1,
  Manufacturer, Part Number 1, Package / Case, Supplier 1, Supplier Part Number 1)
- TOP and BOTTOM VIEW (shows board outline, assembly layer, TOP + BOTTOM layers)
- Mechanical Drawing (Board dimensions, holes position, ..)
- TOP and BOTTOM Assembly Drawing (Component position with Reference Designator)
- 3D Model
